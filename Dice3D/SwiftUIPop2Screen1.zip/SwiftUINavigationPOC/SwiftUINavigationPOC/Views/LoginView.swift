//
//  LoginView.swift
//  SwiftUINavigationPOC
//
//  Created by Raju on 29/12/25.
//

import SwiftUI

struct LoginView: View {
    @StateObject private var router = Router()
    
    var body: some View {
        mainView
        .navigationDestination(for: Screens.self) { screen in
            RouterView(screen: screen)
                .environmentObject(router)
        }
    }
    
    var mainView: some View {
        NavigationStack(path: $router.path) {
            VStack {
                HStack {
                    Button("<") {
                        router.pop()
                    }
                    Spacer()
                    Button("Register") {
                        router.push(.signUp)
                    }

                }.padding(.horizontal)
                
                Divider().background(.gray)
                
                Text("Hello, World! Login")
            }
            Spacer()
        }//.environmentObject(router)
    }
}

//#Preview {
//    LoginView()
//}
