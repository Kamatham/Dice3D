//
//  SignUpView.swift
//  SwiftUINavigationPOC
//
//  Created by Raju on 29/12/25.
//

import SwiftUI

struct SignUpView: View {
    @EnvironmentObject var router: Router
    
    var body: some View {
        VStack {
            HStack {
                Button("<") {
                    router.pop()
                }
                Spacer()
                Button("Forgot Password") {
                    router.push(.forgotPassword)
                }
                
            }.padding(.horizontal)
            
            Divider().background(.gray)
            
            Text("Hello, SignUp")
            Spacer()
        }.onAppear {
            print("signup screen --->>>")
        }
    }
}

//#Preview {
//    SignUpView()
//}
