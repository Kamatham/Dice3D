//
//  ForgotPasswordView.swift
//  SwiftUINavigationPOC
//
//  Created by Raju on 29/12/25.
//

import SwiftUI

struct ForgotPasswordView: View {
    @EnvironmentObject var router: Router
    
    var body: some View {
        VStack {
            HStack {
                Button("<") {
                    router.pop()
                }
                Spacer()
                Button("change Password") {
                    router.push(.changePassword)
                }
                
            }.padding(.horizontal)
            
            Divider().background(.gray)
            
            Text("Hello, ForgotPasswordView")
            Spacer()
        }.onAppear {
            print("ForgotPassword screen --->>>")
        }
    }
}

//#Preview {
//    ForgotPasswordView()
//}
