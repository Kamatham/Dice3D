//
//  ChangePasswordView.swift
//  SwiftUINavigationPOC
//
//  Created by Raju on 29/12/25.
//

import SwiftUI

struct ChangePasswordView: View {
    @EnvironmentObject var router: Router
    
    var body: some View {
        VStack {
            HStack {
                Button("<") {
                    router.pop()
                }
                Spacer()
                Button("Jump to SignUp") {
                    router.pop(to: .signUp)
                }
                
            }.padding(.horizontal)
            
            Divider().background(.gray)
            
            Text("Hello, ChangePasswordView")
            Spacer()
        }
    }
}

//#Preview {
//    ChangePasswordView()
//}
