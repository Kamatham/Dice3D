//
//  Router.swift
//  WellnessApp
//
//  Created by Raju on 08/10/25.
//

import SwiftUI


//struct Router {
//    var initialPath = NavigationPath()
//    
//    @ViewBuilder
//    static func navigateToChildView(screen:Screens, path:Binding<NavigationPath>) -> some View {
//        
//        switch screen {
//            case .login:
//                LoginView()
//                
//            case .signUp:
//                SignUpView(path: path)
//                    .navigationBarBackButtonHidden()
//                
//            case .forgotPassword:
//                ForgotPasswordView(path: path)
//                    .navigationBarBackButtonHidden()
//                
//            case .changePassword:
//                ChangePasswordView(path: path)
//                    .navigationBarBackButtonHidden()
//        }
//    }
//}

final class Router: ObservableObject {
    @Published var path: [Screens] = []
    
    func push(_ screen: Screens) {
        path.append(screen)
    }
    
    func pop() {
        _ = path.popLast()
    }
    
    func popToRoot() {
        path.removeAll()
    }
    
    func pop(to screen: Screens) {
        if let idx = path.lastIndex(of: screen) {
            path = Array(path.prefix(idx + 1))
        }
    }
}

struct RouterView: View {
    @EnvironmentObject var router: Router
    let screen: Screens
    
    var body: some View {
        switch screen {
            case .login:
                LoginView()
                
            case .signUp:
                SignUpView()
                    .navigationBarBackButtonHidden()
                
            case .forgotPassword:
                ForgotPasswordView()
                    .navigationBarBackButtonHidden()
                
            case .changePassword:
                ChangePasswordView()
                    .navigationBarBackButtonHidden()
        }
    }
}


//extension NavigationPath {
//    mutating func push(screen:Screens) {
//        self.append(screen)
//    }
//    
//    mutating func pop() {
//        if !self.isEmpty { self.removeLast() }
//    }
//    
//    mutating func pop(to screen: Screens) {
//
//    }
//    
//    mutating func popToRoot()  {
//        self = NavigationPath()
//    }
//}


enum Screens: Hashable {
    
    case login
    case signUp
    case forgotPassword
    case changePassword
   
}
