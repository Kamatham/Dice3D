//
//  ContentView.swift
//  SwiftUINavigationPOC
//
//  Created by Raju on 29/12/25.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var rootManager: AppRootManager
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world! splash view")
        }.onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                rootManager.launchVideoFinished = true
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

class AppRootManager:ObservableObject {
    
    @Published var launchVideoFinished = false
    @Published var router = Router()
    
    init() {
        
    }
}
