//
//  SwiftUINavigationPOCApp.swift
//  SwiftUINavigationPOC
//
//  Created by Raju on 29/12/25.
//

import SwiftUI

@main
struct SwiftUINavigationPOCApp: App {
    @StateObject var rootManager = AppRootManager()
  
    var body: some Scene {
        WindowGroup {
            content
            
            
        }
    }
    
    var content: some View {
        NavigationStack {
            if rootManager.launchVideoFinished {
                LoginView()
            } else {
                ContentView()
                    .environmentObject(rootManager)
            }
        }
        .navigationBarBackButtonHidden()
    }
}
